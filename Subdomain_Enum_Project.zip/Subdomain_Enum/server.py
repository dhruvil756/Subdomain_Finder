from http.server import BaseHTTPRequestHandler, HTTPServer
import urllib.parse
import subprocess
import os

class MyHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path
        query = urllib.parse.parse_qs(parsed.query)

        # 1️⃣ Run enum.py and stream results
        if path == "/run":
            domain_list = query.get("domain", None)
            if not domain_list:
                self.send_response(400)
                self.end_headers()
                self.wfile.write(b"No domain provided")
                return
            domain = domain_list[0]

            # Start subprocess
            proc = subprocess.Popen(
                ["python", "subdomain_enum.py", domain],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True
            )

            self.send_response(200)
            self.send_header("Content-Type", "text/plain; charset=utf-8")
            self.end_headers()

            # Stream stdout line by line
            for line in proc.stdout:
                self.wfile.write(line.encode())
                self.wfile.flush()

            proc.wait()

        # 2️⃣ Download the results file
        elif path == "/download":
            file_path = "discoverd_subdomain.txt"
            if os.path.exists(file_path):
                self.send_response(200)
                self.send_header("Content-Type", "application/octet-stream")
                self.send_header("Content-Disposition", f"attachment; filename={file_path}")
                self.end_headers()
                with open(file_path, "rb") as f:
                    self.wfile.write(f.read())
            else:
                self.send_response(404)
                self.end_headers()
                self.wfile.write(b"File not found")

        # 3️⃣ Serve HTML
        elif path == "/" or path.endswith(".html"):
            html_file = "index.html"
            if os.path.exists(html_file):
                self.send_response(200)
                self.send_header("Content-type", "text/html")
                self.end_headers()
                with open(html_file, "rb") as f:
                    self.wfile.write(f.read())
            else:
                self.send_response(404)
                self.end_headers()
                self.wfile.write(b"HTML file not found")

        else:
            self.send_response(404)
            self.end_headers()
            self.wfile.write(b"Not Found")

# Start server
if __name__ == "__main__":
    server = HTTPServer(("localhost", 8000), MyHandler)
    print("Server running at http://localhost:8000")
    server.serve_forever()
