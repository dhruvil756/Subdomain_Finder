import requests #Used to send request
import dns.resolver
import socket
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed
domain_name=sys.argv[1] if len(sys.argv) > 1 else None

def check_domain_existence(domain_name):#Check domain is valid or not 
     try:
          socket.gethostbyname(domain_name)
          return True
     except socket.gaierror:
          return False
if not check_domain_existence(domain_name):
    print("Please enter a valid domain", flush=True)
    sys.exit()

found_subdomain_list=[]

with open("subdomains.txt",'r')as file:#Open Subdomain list for read subdomain 
     subdomains=file.read().splitlines()

def check_subdomain(subdomain):#For checking subdomains 
        url=f"http://{subdomain}.{domain_name}"
        try:
                response=requests.get(url,timeout=3)
                result=f"[+] {url} ->   {response.status_code}" 
                found_subdomain_list.append(result)
                print(result,flush=True)
                return result
        except requests.ConnectionError:
            pass
             
MAX_THREAD=50#Thread limit 
           
with ThreadPoolExecutor(max_workers=MAX_THREAD)as executor:#Managing thread  maximum 50 thread
    
    futures=[executor.submit(check_subdomain,subdomain)for subdomain in subdomains]
    for f in as_completed(futures):
        pass
with open("discoverd_subdomain.txt",'w')as f:#Write all valid subdomain in file 
     for subdomain in found_subdomain_list:
        print(subdomain,file=f)
